import { read_json } from './utils/files.js';

// get options
let options = read_json('./options.json');

export default options
