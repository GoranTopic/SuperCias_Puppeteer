import Docker from 'dockerode'


// create docker instance
var docker = new Docker({host: '0.0.0.0', port: 3000})

let auxContainer;
await docker.createContainer({
    Image: 'supercias',
    t: 'supercias_cont',
    AttachStdin: false,
    AttachStdout: true,
    AttachStderr: true,
    Tty: true,
    Cmd: ['/bin/bash', '-c', 'tail -f /var/log/dmesg'],
    OpenStdin: false,
    StdinOnce: false
}).then(function(container){
    auxContainer = container;
    //console.log(auxContainer);
})

docker.listContainers( (err, containers) =>{
    containers.forEach( contInfo => {
        console.log(contInfo.id);
        let result = docker.getContainer(contInfo.Id)
            .start( () => console.log('cb ran'))
        console.log(result);
    })
})




//console.log( (await docker.listImages()).map( ({ RepoTags, Id }) => ({RepoTags, Id})))


/*
docker.createContainer({Image: 'ubuntu', Cmd: ['/bin/bash'], name: 'ubuntu-test'},
    function (err, container) {
        console.error(err)
        console.log(container)
        container.start(function (err, data) {
            console.error(err)
            console.error(data)
        });
    });

*/




//let image = await docker.buildImage('Dockerfile.tar', {t: 'supercia'});

/*
console.log( 
    (docker.listImages()).map(
        ({ RepoTags, Id }) => ({RepoTags, Id})
    )
)
*/

/*
console.log(
    docker.createContainer({
        Image: 'ubuntu', 
        Cmd: ['/bin/bash'],
        name: 'testing',
        //Volumes: { "/home/telix/supercias/data/":"/home/pptruser/supercias/data", },
        cap_add: 'SYS_ADMIN',
    }, function (err, container) {
        if(err){
            console.error(err);
        }else{
            container.start(function (err, data) {
                console.log(data)
            });
        }
    })
)
*/

//console.log(stream)

/*
let stream = await docker.buildImage(
    { context: '/home/telix/supercias/', src: [ 'Dockerfile' ] },
    { t: 'supercias_image' },
    ( error, response ) => {
        console.log('response:', response);
        console.log('error:', error);
        return response
    }
);
*/

/*
await new Promise((resolve, reject) => {
  docker.modem.followProgress(stream, (err, res) => err ? reject(err) : resolve(res));
});
*/

//await new Promise((resolve, reject) => { docker.modem.followProgress(stream, (err, res) => err ? reject(err) : resolve(res)); });

/*
console.log( 
    (await docker.listImages()).map(
        ({ RepoTags, Id }) => ({RepoTags, Id})
    )
)
*/

//let image = (await docker.listImages())[2]

//console.log(image);
