!#/bin/bash

for tesseract to work you need nodejs verion < 17.19
to use nodejs version 17.19 use the following commands:

    sudo apt install curl

    curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash 

then run:

    nvm install 17
